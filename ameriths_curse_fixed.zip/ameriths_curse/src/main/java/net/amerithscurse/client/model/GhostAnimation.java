package net.amerithscurse.client.model;

// Corrected from JSON wrapper to actual Java class definition
public class GhostAnimation {
    // Your Blockbench animation bones and keyframe definitions go here!
    public GhostAnimation() {
        // Animation setup
    }
}
